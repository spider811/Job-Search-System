package com.cg.jss;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobSearchSystemApplicationTests {

	
	void contextLoads() {
	}

}
