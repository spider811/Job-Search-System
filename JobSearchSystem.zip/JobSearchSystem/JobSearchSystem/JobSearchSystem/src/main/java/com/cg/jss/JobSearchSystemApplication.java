package com.cg.jss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobSearchSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobSearchSystemApplication.class, args);
	}

}
